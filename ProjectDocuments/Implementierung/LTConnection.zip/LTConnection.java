package edu.kit.anthropomatik.h2t.pepper.basicapp;


import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Log;
import android.util.Pair;

import androidx.annotation.RequiresApi;

import com.launchdarkly.eventsource.MessageEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import edu.kit.anthropomatik.h2t.pepper.basicapp.messages.LTMessage;
import edu.kit.anthropomatik.h2t.pepper.basicapp.messages.LTMessageList;
import edu.kit.anthropomatik.h2t.pepper.basicapp.sse.SSEClient;
import edu.kit.anthropomatik.h2t.pepper.basicapp.sse.SSEHandler;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class LTConnection implements SSEHandler {

    private static final String TAG = "LTConnection";
    private static final String LT_URL_MAIN = "https://lecture-translator.kit.edu/";
    private static final String LT_URL_DEV = "https://lt2srv-backup.iar.kit.edu/";
    private static final String LT_URL_DEV_LOCAL = "";
    private static final String API = "webapi";
    private static final String TOKEN_MAIN = "";
    private static final String TOKEN_DEV = "";
    private static final String CONTROLL = "controll";
    private static final String APPEND = "/append";
    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    private final String url;
    private final String token;
    private final OkHttpClient httpClient;
    private boolean localhost;
    private final String sessionId;
    private final String streamId;
    private final int bufferSize;
    private final AudioRecord audioRecord;
    private final SSEClient sseClient;
    private boolean keepSending;
    private boolean paused;
    private LTMessageList msgList;

    /**
     * To start the audio recording / sending: Call runSession()!
     * Sets up the HTTP connection to the dev pipeline of the LT server.
     * Requests a session.
     * Configures Android AudioRecord.
     * Audio segmenter of ASR on by default.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public LTConnection() {
        this(true, true, LTPipeline.DEV);
    }

    /**
     * To start the audio recording / sending: Call runSession()!
     * Sets up the HTTP connection to the dev pipeline of the LT server.
     * Requests a session.
     * Configures Android AudioRecord.
     * @param segmenter If the ASR should use an audio segmenter.
     * @param speakerDiarization If the ASR should do speaker diarization.
     *                           Segmenter is needed for this.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public LTConnection(boolean segmenter, boolean speakerDiarization) {
        this(segmenter, speakerDiarization, LTPipeline.DEV);
    }

    /**
     * To start the audio recording / sending: Call runSession()!
     * Sets up the HTTP connection to the LT server.
     * Requests a session.
     * Configures Android AudioRecord.
     * @param segmenter If the ASR should use an audio segmenter.
     * @param speakerDiarization If the ASR should do speaker diarization.
     *                           Segmenter is needed for this.
     * @param lTPipeline Which pipeline (main, dev, local) the connection should use.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public LTConnection(boolean segmenter, boolean speakerDiarization, LTPipeline lTPipeline) {
        // Deny if segmenter is off, but speakerDiarization on
        if (!segmenter && speakerDiarization) {
            throw new IllegalArgumentException("Segmenter is need for speaker diarization!");
        }

        this.localhost = false;
        if (lTPipeline == LTPipeline.MAIN) {
            this.url = LT_URL_MAIN;
            this.token = TOKEN_MAIN;
        } else if (lTPipeline == LTPipeline.DEV) {
            this.url = LT_URL_DEV;
            this.token = TOKEN_DEV;
        } else {
            this.url = LT_URL_DEV_LOCAL;
            this.token = "";
            this.localhost = true;
        }

        this.keepSending = true;
        this.paused = true;

        // Setup connection and request session / stream id.
        this.httpClient = new OkHttpClient();

        //Pair<String, String> ids = this.setDefaultAsrGraph(segmenter, speakerDiarization);
        Pair<String, String> ids = null;
        try {
            ids = this.setStartDialogGraph(false);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        this.sessionId = ids.first;
        this.streamId = ids.second;
        Log.i(TAG, "sessionId: " + sessionId + ", " + "streamId: " + streamId);

        // Setup audio recording.
        this.bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING);
        Log.i(TAG, "this.bufferSize: " + this.bufferSize);
        this.audioRecord = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, SAMPLE_RATE, CHANNEL, ENCODING, this.bufferSize);

        // Setup SSEClient.
        String url = this.url + API + "/stream?channel=" + this.sessionId;
        this.sseClient = new SSEClient(url, this, this.localhost);

        this.msgList = new LTMessageList(8);
    }

    /**
     * Returns the full conversation history as a String.
     * @return The full conversation history as a String.
     */
    public String getFullConv() {
        return this.msgList.toString();
    }

    /**
     * Return the newest bot message.
     * @return The newest bot message. Null if no newest.
     */
    public LTMessage getLastBotMsg() {
        if (this.msgList.hasNewMsg()) {
            LTMessage msg = this.msgList.getNewestBotMsg();
            return msg;
        }
        return null;
    }

    /**
     * Pauses the audio recording and sending.
     * Not yet received transcripts may still arrive.
     */
    public void pauseAudio() {
        this.paused = true;
        this.audioRecord.stop();
    }

    /**
     * Continues the audio recording and sending.
     */
    public void unpauseAudio() {
        this.paused = false;
    }

    /**
     * Ends this session with the LT server.
     * Must be called after usage of this connection (e.g. when closing the app).
     */
    public void endSession() {
        this.keepSending = false;
        this.sendEnd();
        //this.audioRecord.release();
    }

    /**
     * Same as post() but with the session and stream id already added to the URL.
     * @param url The ending of the URL the request should be sent to. Session and stream id already included.
     * @param jsonData JSON data in String form.
     * @return The answer from the server in String form.
     */
    private String postWithIds(String url, String jsonData) {
        return this.post(this.sessionId + "/" + this.streamId + url, jsonData);
    }

    /**
     * Send a HTTP request to the LT server.
     * @param url The ending of the URL the request should be sent to.
     * @param jsonData JSON data in String form.
     * @return The answer from the server in String form.
     */
    private String post(String url, String jsonData) {
        Request request = this.createRequest(url, jsonData);

        String responseBody = "";
        try {
            Response response = this.httpClient.newCall(request).execute();
            responseBody = response.body().string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return responseBody;
    }

    private Request createRequest(String url, String jsonData) {
        RequestBody requestBody = RequestBody.create(jsonData, MediaType.get("application/json; charset=utf-8"));
        Request.Builder builder = new Request.Builder()
                .url(this.url + API + "/" + url)
                .post(requestBody)
                .addHeader("Cookie", "_forward_auth=" + this.token);
        if (this.localhost) {
            builder.addHeader("Host", "localhost");
        }
        return builder.build();
    }

    private static String normalJsonStringToLtJsonString(String json) {
        String edit_json = json.replace("True", "\"True\"");
        edit_json = edit_json.replace("False", "\"False\"");
        edit_json = edit_json.replace("None", "\"None\"");
        return "\"" + edit_json.replace("\"", "\\\"") + "\"";
    }

    private static String createControllJsonDict(String command) {
        return "{\"" + CONTROLL + "\":\"" + command + "\"}";
    }

    private Pair<String, String> setStartDialogGraph(boolean tts) throws JSONException {
        JSONObject requestJsonObject = new JSONObject();
        requestJsonObject.put("bot", "bot");
        if (tts) {
            requestJsonObject.put("tts", "\"TRUE\"");
        }

        // Send request for new dialog.
        String ids = this.post("start_dialog", normalJsonStringToLtJsonString(requestJsonObject.toString()));
        Log.i(TAG, "ids: " + ids);
        String[] ids_split = ids.split(" ");

        // Get graph (just to show it).
        String graph = this.post(ids_split[0] + "/getgraph", "");
        Log.i(TAG, "graph: " + graph);

        return new Pair<>(ids_split[0], ids_split[1]);
    }


    private String getAvailableLanguagesString() throws JSONException {
        StringBuilder availableLanguages = new StringBuilder();

        JSONObject availableLanguagesJson = this.getAvailableLanguages();
        JSONArray asr = availableLanguagesJson.getJSONArray("asr");

        for (int i = 0; i < asr.length(); i++) {
            JSONArray langItem = (JSONArray) asr.get(i);
            String lang_id = langItem.getString(0);

            availableLanguages.append(lang_id).append("+");
        }
        return availableLanguages.substring(0, availableLanguages.length() - 1);
    }

    private JSONObject getAvailableLanguages() {
        String response = this.post("list_available_languages", "");
        try {
            return new JSONObject(response);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void runSession() {
        this.runSession("");
    }

    /**
     * Starts and runs the newly created connection to the LT server.
     * Audio is now recorded and sent.
     * Must be stopped with endSession() after usage.
     * @param systemPrompt The default system prompt can be replaced with a custom one.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void runSession(String systemPrompt) {
        this.sseClient.initSse();

        // To make sure the SSEClient is running before sending the INFORMATION request
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Log.i(TAG, "Requesting worker informations");
        String data = createControllJsonDict("INFORMATION");
        this.postWithIds(APPEND, normalJsonStringToLtJsonString(data));

        this.sendSession(systemPrompt);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void sendSession(String systemPrompt) {
        try {
            this.sendStart(systemPrompt);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        Log.i(TAG, "this.audioRecord.getState(): " + this.audioRecord.getState());
        Log.i(TAG, "AudioRecord.STATE_INITIALIZED: " + AudioRecord.STATE_INITIALIZED);

        float lastTime = 0;
        this.paused = false;
        while (this.keepSending) {
            // Do nothing if audio is paused.
            if (this.paused) {
                try {
                    TimeUnit.MILLISECONDS.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else {
                lastTime = this.sendAudio(lastTime);
            }
        }

        this.audioRecord.stop();

        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        this.sendEnd();
    }

    private String sendStart(String systemPrompt) throws JSONException {
        Log.i(TAG, "Start sending audio.");

        // Send START and also configure that this is the child robot including location of context.
        JSONObject requestJsonObject = new JSONObject();
        requestJsonObject.put(CONTROLL, "START");
        requestJsonObject.put("bot", "childRobot");
        if (!(systemPrompt.isEmpty())) {
            requestJsonObject.put("system_prompt", systemPrompt);
        }

        return this.postWithIds(APPEND, normalJsonStringToLtJsonString(requestJsonObject.toString()));
    }

    private String sendEnd() {
        Log.i(TAG, "Sending END.");
        this.sseClient.disconnect();
        //this.audioRecord.release();
        String data = createControllJsonDict("END");
        return this.postWithIds(APPEND, normalJsonStringToLtJsonString(data));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static float timeTime() {
        Instant instant = Instant.now();
        return (float) instant.toEpochMilli();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private float sendAudio(float time) {
        // Record some audio.
        this.audioRecord.startRecording();
        byte[] audioData = new byte[this.bufferSize];
        int byteRead = this.audioRecord.read(audioData, 0, audioData.length);
        //this.audioRecord.stop();
        //Log.i(TAG, "byteRead:" + byteRead);

        // Encode it.
        // Longer version-
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            bos.write(audioData);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        String base64Encoded = Base64.getEncoder().encodeToString(bos.toByteArray());
        String asciiDecoded = new String(base64Encoded.getBytes(StandardCharsets.UTF_8), StandardCharsets.US_ASCII);

        // Shorter version (unused for now).
        //String base64EncodedAudio = Base64.getEncoder().encodeToString(audioData);

        //Log.i(TAG, "asciiDecoded:" + asciiDecoded);

        // Get start and end time.
        //float s = timeTime();
        float s = time;
        float e = s + (audioData.length / (float) (2 * SAMPLE_RATE));
        //Log.i(TAG, "s:" + s);

        // Convert to JSON string and send it.
        String data = "{\"b64_enc_pcm_s16le\": \"" + asciiDecoded + "\", \"start\": " + s + ",\"end\":" + e + "}";
        this.postWithIds(APPEND, normalJsonStringToLtJsonString(data));

        return e;
    }

    @Override
    public void onSSEConnectionOpened() {
        Log.i(TAG, "SSEClient connection opened.");
    }

    @Override
    public void onSSEConnectionClosed() {
        Log.i(TAG, "SSEClient connection closed.");
    }

    @Override
    public void onSSEEventReceived(String event, MessageEvent messageEvent) {
        String msgData = messageEvent.getData();
        JSONObject msgDataJson;
        try {
            msgDataJson = new JSONObject(msgData);
            if (msgDataJson.has(CONTROLL)) {
                String controll = msgDataJson.getString(CONTROLL);
                if (controll.equals("START") || controll.equals("INFORMATION") || controll.equals("END")) {
                    Log.i(TAG, "msgDataJson with CONTROLL: " + msgDataJson);
                }
            }
            if (msgDataJson.has("seq")) {
                Log.i(TAG, "msgDataJson with seq: " + msgDataJson);
                this.msgList.add(msgDataJson);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onSSEError(Throwable t) {
        Log.i(TAG, "SSEClient error: " + t);
    }


    // Ab hier Methoden die irgendwie nicht mehr benutzt werden


    private Pair<String, String> setDefaultAsrGraph(boolean segmenter, boolean speakerDiarization) {
        // Lecture Translator expects double encoded JSON as string.
        //Add properties if wanted.

        String availableLanguages = "en+de";
        try {
            availableLanguages = this.getAvailableLanguagesString();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        String asrProp = "";
        if (!segmenter) {
            asrProp = "\"segmenter\": None";
        }
        String sd = "";
        if (speakerDiarization) {
            sd = "\"speakerdiarization\": True, ";
        }
        String command = "{\"language\": \"" + availableLanguages + "\", \"log\": True, " + sd + "\"textseg\": false, \"error_correction\": None, \"asr_prop\": {" + asrProp + "}, \"mt_prop\": {}, \"prep_prop\": {}, \"textseg_prop\": {}, \"tts_prop\": {}, \"lip_prop\": {}}";
        //Request session for default asr.
        String ids = this.post("get_default_asr", normalJsonStringToLtJsonString(command));
        Log.i(TAG, "ids: " + ids);
        String[] ids_split = ids.split(" ");

        // Get graph (just to show it).
        String graph = this.post(ids_split[0] + "/getgraph", "");
        Log.i(TAG, "graph: " + graph);

        return new Pair<>(ids_split[0], ids_split[1]);
    }



    private static String extractSpeakerId(String fullSpeakerId) {
        String[] fullSpeakerIdSplit = fullSpeakerId.split(":");
        String speakerUnkId = fullSpeakerIdSplit[fullSpeakerIdSplit.length - 1];
        String[] speakerUnkIdSplit = speakerUnkId.split("-");
        return speakerUnkIdSplit[1];
    }

    private static String speakerAndMsgToConvLine(String speakerId, String msg) {
        return "speaker " + speakerId + ":" + msg;
    }

    /**
     * Check if this connection is running and not ended.
     * @return Run status.
     */
    public boolean isRunning() {
        return this.keepSending;
    }




}




