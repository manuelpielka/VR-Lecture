package edu.kit.anthropomatik.h2t.pepper.basicapp;

/**
 * Defines the different possible Lecture Translator pipelines.
 */
public enum LTPipeline {
    MAIN,
    DEV,
    LOCAL
}
