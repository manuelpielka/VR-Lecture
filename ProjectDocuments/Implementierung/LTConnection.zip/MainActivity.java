package edu.kit.anthropomatik.h2t.pepper.basicapp;

import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import com.aldebaran.qi.sdk.QiContext;
import com.aldebaran.qi.sdk.QiSDK;
import com.aldebaran.qi.sdk.RobotLifecycleCallbacks;
import com.aldebaran.qi.sdk.design.activity.RobotActivity;

import org.json.JSONException;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import edu.kit.anthropomatik.h2t.pepper.basicapp.messages.LTMessage;

public class MainActivity extends RobotActivity implements RobotLifecycleCallbacks {
    private static final String TAG = "MainActivity";
    private static final String TAGLLM = "LLM Response";

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;

    private Button buttonPepper;
    private Button buttonStart;
    private Button buttonPause;
    private Button buttonUnpause;
    private Button buttonEnd;

    private Button buttonLlama;

    private TextView resultTextView;

    QiContext qiContext;
    LTConnection ltConnection;

    private String lastMsgForPepperToSay = "";

    String lastRobotMsg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "Running onCreate().");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Register the RobotLifecycleCallbacks to this Activity.
        Log.d(TAG, "Registering QiSDK...");
        QiSDK.register(this, this);
        Log.d(TAG, "Done!");
        Log.i(TAG, "Oncreate()");
        // Request permission to record audio.
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);

        Log.i(TAG, "requested permissions");
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<LTConnection> future = executor.submit(new Callable<LTConnection>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public LTConnection call() {
                return new LTConnection(true, true, LTPipeline.DEV);
            }
        });

        Log.i(TAG, "initializing ltConnection");

        try {
            ltConnection = future.get();
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        Log.i(TAG, "Done!");

        buttonStart = findViewById(R.id.button_audio_start);
        LTConnection finalLtConnection = ltConnection;

        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.i(TAG, "Pressed audio start.");
                //buttonEnd.setEnabled(false);
                //buttonEnd.setClickable(false);
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        finalLtConnection.runSession();
                    }
                }).start();
            }
        });

        buttonEnd = findViewById(R.id.button_audio_end);

        LTConnection finalLtConnection1 = ltConnection;
        buttonEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio end.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        //buttonStart.setEnabled(true);
                        //buttonStart.setClickable(true);
                        //buttonEnd.setEnabled(false);
                        //buttonEnd.setClickable(false);
                        finalLtConnection1.endSession();
                    }
                }).start();
            }
        });

        resultTextView = findViewById(R.id.result);
        resultTextView.setText("<no message yet>");
        resultTextView.setMovementMethod(new ScrollingMovementMethod());



        buttonPause = findViewById(R.id.button_audio_pause);
        buttonPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio pause.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        Log.i(TAG, "entered the run");
                        finalLtConnection1.pauseAudio();

                        // Get the messages.
                        LTConnection finalLtConnection2 = ltConnection;
                        final String conv;
                        LTMessage lastBotMsg;
                        synchronized (finalLtConnection2) {
                            conv = finalLtConnection2.getFullConv();
                            lastBotMsg = finalLtConnection2.getLastBotMsg();
                            if (lastBotMsg != null) {
                                Log.i(TAG, "Language of message:\t" + lastBotMsg.getLocale().toString());
                                Log.i(TAG, "String generated: " + lastBotMsg.toString());
                            }
                        }
                        synchronized (conv) {// Display the data using the UI thread again.
                            MainActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    resultTextView.setText(conv);
                                    if (lastBotMsg != null) {
                                        Log.i(TAG, "entering sleep");
                                        while(true) {
                                            if (lastBotMsg.toString() != lastRobotMsg) {
                                                break;
                                            }
                                        }
                                        Log.i(TAG, "exiting sleep");
                                        lastRobotMsg = lastBotMsg.toString();
                                        PepperActivity.pepperSayAsync(qiContext, lastRobotMsg, lastBotMsg.getLocale());
                                    }
                                }
                            });
                        }
                    }

                }).start();
            }
        });

        buttonUnpause = findViewById(R.id.button_audio_unpause);

        buttonUnpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio unpause.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        finalLtConnection1.unpauseAudio();
                    }
                }).start();
            }
        });

        //Pepper Button raus :)
        // buttonPepper = findViewById(R.id.button_pepper);

        //buttonLlama = findViewById(R.id.button_llama);

        /*

        buttonLlama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Ask Llama button pressed.");

                new Thread(() -> {
                    try {
                        // Abrufen der letzten Nachricht aus LTConnection
                        String conv = ltConnection.getFullConv();
                        if (conv.isEmpty()) {
                            Log.w(TAG, "No messages found in LTConnection.");
                            runOnUiThread(() -> resultTextView.setText("Keine Nachricht gefunden."));
                            return;
                        }

                        Log.i(TAG, "Conversation history from LT:\n" + conv);

                        LTMessage botMsg = ltConnection.getLastBotMsg();
                        Log.i(TAG, "Language of message:\t" + botMsg.getLocale().toString());

                        if (qiContext != null) {
                            if (!(botMsg.toString().isEmpty())) {
                                //PepperActivity.pepperSay(qiContext, botMsg.toString());
                                Log.d(TAG, "2. Updating UI with response: " + botMsg);
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing LLM response: " + e.getMessage());
                        runOnUiThread(() -> resultTextView.setText("Fehler beim Verarbeiten der Antwort."));
                    }
                }).start();
            }
        });
         */


    }

    @Override
    protected void onDestroy() {
        // Unregister the RobotLifecycleCallbacks for this Activity.
        //QiSDK.unregister(this, this);
        super.onDestroy();
    }

    @Override
    public void onRobotFocusGained(QiContext qiContext) {
        // The robot focus is gained.
        Log.i(TAG, "Robot focus is gained.");
        this.qiContext = qiContext;

        // Button-Pepper Interaktion definieren
        /*
        Der Pepper Button wurde entfernt, da keine gescheite Interaktion definiert wurde
         */
        /*
        buttonPepper.setOnClickListener(v -> new Thread(() -> {
            if (qiContext != null && ltConnection != null) {
                  Log.i(TAG, "Pepper button was clicked");

            } else {
                Log.e(TAG, "QiContext or LTConnection is null!");
            }
        }).start());

         */
    }


    @Override
    public void onRobotFocusLost() {
        // The robot focus is lost.
        Log.i(TAG, "Robot focus is lost.");
    }

    @Override
    public void onRobotFocusRefused(String reason) {
        // The robot focus is refused.
        Log.i(TAG, "Robot focus is refused." + reason);
    }


}

