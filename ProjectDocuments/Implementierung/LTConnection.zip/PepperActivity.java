package edu.kit.anthropomatik.h2t.pepper.basicapp;



import com.aldebaran.qi.Future;
import com.aldebaran.qi.sdk.QiContext;
import com.aldebaran.qi.sdk.builder.SayBuilder;
import com.aldebaran.qi.sdk.object.conversation.Say;
import com.aldebaran.qi.sdk.object.locale.Language;
import com.aldebaran.qi.sdk.object.locale.Locale;

public class PepperActivity {

    /**
     * Führt den Say-Vorgang komplett asynchron aus (inkl. build).
     * @param qiContext - Kontext von Pepper
     * @param text - Der zu sprechende Text
     * @param locale - Gewünschte Locale (z.B. Locale.GERMANY)
     * @return Future<Void> - erlaubt dir, auf Erfolg oder Fehler zu reagieren
     */
    public static Future<Void> pepperSayAsync(QiContext qiContext, String text, Locale locale) {
        // Asynchrones Bauen des Say-Objekts
        Future<Say> sayFuture = SayBuilder.with(qiContext)
                .withText(text)
                .withLocale(locale)
                .buildAsync();

        // Wenn das Say-Objekt fertig ist, asynchron ausführen
        Future<Void> runFuture = sayFuture.andThenCompose(say -> say.async().run());

        // Optional: direkter Konsum des Ergebnisses
        runFuture.thenConsume(future -> {
            if (future.isSuccess()) {
                System.out.println("Text wurde erfolgreich gesprochen.");
            } else {
                System.err.println("Fehler beim Sprechen: " + future.getError());
            }
        });

        return runFuture;
    }

}




