package edu.kit.anthropomatik.h2t.pepper.basicapp;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.text.method.ScrollingMovementMethod;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.aldebaran.qi.sdk.AuthData;
import com.aldebaran.qi.sdk.QiContext;

import org.json.JSONException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import edu.kit.anthropomatik.h2t.pepper.basicapp.messages.LTMessage;


public class RecognitionActivity extends AppCompatActivity {
    private static final String TAG = "RecognitionActivity";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;

    private Button buttonStart;
    private Button buttonPause;
    private Button buttonUnpause;
    private Button buttonEnd;

    QiContext qiContext;


    private TextView resultTextView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recognition);

        Log.i(TAG, "Oncreate()");
        // Request permission to record audio.
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);

        Log.i(TAG, "requested permissions");
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<LTConnection> future = executor.submit(new Callable<LTConnection>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public LTConnection call() {
                return new LTConnection(false, false);
            }
        });

        Log.i(TAG, "initializing ltConnection");
        LTConnection ltConnection = null;
        try {
            ltConnection = future.get();
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        Log.i(TAG, "Done!");

        // Add buttons.
        buttonStart = findViewById(R.id.button_audio_start);
        LTConnection finalLtConnection = ltConnection;
        /*buttonStart.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio start.");
                //finalLtConnection.runSession();
            }
        });*/
        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.i(TAG, "Pressed audio start.");
                //buttonEnd.setEnabled(false);
                //buttonEnd.setClickable(false);
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        finalLtConnection.runSession();
                    }
                }).start();
            }
        });
        buttonEnd = findViewById(R.id.button_audio_end);

        LTConnection finalLtConnection1 = ltConnection;
        buttonEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio end.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        //buttonStart.setEnabled(true);
                        //buttonStart.setClickable(true);
                        //buttonEnd.setEnabled(false);
                        //buttonEnd.setClickable(false);
                        finalLtConnection1.endSession();
                    }
                }).start();
            }
        });

        buttonPause = findViewById(R.id.button_audio_pause);
        buttonPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio pause.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        finalLtConnection1.pauseAudio();
                    }
                }).start();
            }
        });

        buttonUnpause = findViewById(R.id.button_audio_unpause);

        buttonUnpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pressed audio unpause.");
                new Thread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        finalLtConnection1.unpauseAudio();
                    }
                }).start();
            }
        });




        resultTextView = findViewById(R.id.result);
        resultTextView.setText("<no message yet>");
        resultTextView.setMovementMethod(new ScrollingMovementMethod());

        // Get the messages.
        LTConnection finalLtConnection2 = ltConnection;
        //String languages = finalLtConnection2.getAvailableLanguages().toString();
        //Log.d(TAG, "Available Languages:", languages);
        //resultTextView.setText(languages);
        Timer timer = new Timer();
        // Get the data via an extra thread.
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //Log.i(TAG, "Retrieving messages...");
                final String msgs;

                synchronized (finalLtConnection2) {
                    msgs = finalLtConnection2.getFullConv();

                }
                synchronized (msgs) {
                    //String msgsString = String.join("\n", msgs);
                    // Log.i(TAG, "Heard:" + msgsString);

                    // Display the data using the UI thread again.
                    RecognitionActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i(TAG, "Message is printed hier" + msgs);
                            resultTextView.setText(msgs);
                        }
                    });
                }
            }
        };
        // Schedule the task to run every 10 milliseconds.
        timer.schedule(task, 0, 10);

    }
}
