package edu.kit.anthropomatik.h2t.pepper.basicapp;

import android.util.Log;

import com.aldebaran.qi.sdk.AuthData;

import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.common.IOUtils;
import net.schmizz.sshj.connection.ConnectionException;
import net.schmizz.sshj.connection.channel.direct.Session;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.io.IOException;
import java.security.Security;
import java.util.concurrent.TimeUnit;


public class SSHConnection {
    private SSHClient client;
    private final AuthData credentials;

    /**
     * Initalisiert eine neue SSH Verbindung
     *
     * @param credentials die Verbindungsdaten für die SSH Verbindung
     * @throws IOException the io exception
     */
    public SSHConnection(AuthData credentials) throws IOException {
        this.credentials = credentials;
        connectClient();
    }

    private void connectClient() throws IOException {
        this.client = new SSHClient();
        this.client.setConnectTimeout(5000);
        this.client.addHostKeyVerifier(credentials.getSshIdentifier());
        this.client.connect(credentials.getIp(), credentials.getSshPort());
        this.client.authPassword(credentials.getUsername(), credentials.getPassword());
    }


    public void executeCommand(String command) throws IOException {
        Session session = this.client.startSession();
        Session.Command cmd = session.exec(command);
        try {
            cmd.join(3, TimeUnit.SECONDS);
        }catch (ConnectionException ignored){
        }
        session.close();
    }

    static {
        Security.removeProvider("BC");
        Security.insertProviderAt(new BouncyCastleProvider(), 1);
    }

}
