package edu.kit.anthropomatik.h2t.pepper.basicapp;


import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.aldebaran.qi.sdk.AuthData;
import com.aldebaran.qi.sdk.QiSDK;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;

public class SplashActivity extends AppCompatActivity {


    private static final String TAG = "SplashActivity";
    private static final String PREFS_NAME = "RobotPrefs";
    private static final String KEY_IP_HISTORY = "ipHistory";
    private static final String KEY_LAST_USED_IP = "lastUsedIp";

    private Button buttonRestart;
    private Button buttonWithoutRobot;
    private Button buttonClearHistory;
    private TextView textView;
    private CheckBox debugModeCheckbox;
    private AutoCompleteTextView editTextRobotIp;


    private static final int REQUEST_CODE_PERMISSIONS = 1;
    private String parsedIp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();

        checkAndRequestPermissions();

        buttonWithoutRobot = findViewById(R.id.buttonWithoutRobot);
        debugModeCheckbox = findViewById(R.id.debugModeCheckbox);
        editTextRobotIp = findViewById(R.id.editTextRobotIp);

        buttonWithoutRobot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity(false, debugModeCheckbox.isChecked());
            }
        });

        textView = findViewById(R.id.message);


        buttonClearHistory = findViewById(R.id.buttonClearHistory);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Check if there's anything to clear
        boolean hasHistory = prefs.contains(KEY_IP_HISTORY) || prefs.contains(KEY_LAST_USED_IP);
        buttonClearHistory.setEnabled(hasHistory);

        // Set click listener
        buttonClearHistory.setOnClickListener(v -> {
            if (hasHistory) {
                prefs.edit().remove(KEY_IP_HISTORY).remove(KEY_LAST_USED_IP).apply();
                editTextRobotIp.setText(parsedIp); // Reset to parsed IP
                editTextRobotIp.setAdapter(null);

                Toast.makeText(this, "IP history cleared", Toast.LENGTH_SHORT).show();
                buttonClearHistory.setEnabled(false); // Disable after clearing
            }
        });


        editTextRobotIp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String ip = s.toString().trim();
                if (!ip.isEmpty() && !Patterns.IP_ADDRESS.matcher(ip).matches()) {
                    editTextRobotIp.setError("Invalid IP address");
                } else {
                    editTextRobotIp.setError(null); // Clear error
                }
            }
        });

        loadIpHistory();

        // Default behavior: run with robot
        startMainActivity(true, debugModeCheckbox.isChecked());
    }

    private void loadIpHistory() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Set<String> ipSet = prefs.getStringSet(KEY_IP_HISTORY, new HashSet<>());
        List<String> ipList = new ArrayList<>(ipSet);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, ipList);
        editTextRobotIp.setAdapter(adapter);

        String lastUsedIp = prefs.getString(KEY_LAST_USED_IP, "");
        if (!lastUsedIp.isEmpty() && editTextRobotIp.getText().toString().isEmpty()) {
            //editTextRobotIp.setHint("Last used: " + lastUsedIp);
            editTextRobotIp.setText(lastUsedIp);
        }
    }


    private void checkAndRequestPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.INTERNET);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.MODIFY_AUDIO_SETTINGS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.MODIFY_AUDIO_SETTINGS);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.RECORD_AUDIO);
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), REQUEST_CODE_PERMISSIONS);
        }
    }

    private boolean saveIpToHistory(String ip) {
        if (ip == null || ip.isEmpty()) return false;

        if (ip.equals(parsedIp)) return false;

        if (!Patterns.IP_ADDRESS.matcher(ip).matches()) {
            return false; // Invalid IP
        }

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String lastUsedIp = prefs.getString(KEY_LAST_USED_IP, "");

        if (ip.equals(lastUsedIp)) {
            return false; // Already the last used
        }

        Set<String> ipSet = new HashSet<>(prefs.getStringSet(KEY_IP_HISTORY, new HashSet<>()));
        ipSet.add(ip);
        prefs.edit()
                .putStringSet(KEY_IP_HISTORY, ipSet)
                .putString(KEY_LAST_USED_IP, ip)
                .apply();
        return true; // Successfully saved
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, permissions[i] + " permission granted.");
                } else {
                    Log.e(TAG, permissions[i] + " permission denied.");
                }
            }
        }
    }

    private void startMainActivity(boolean withRobot, boolean debugMode) {
        Executors.newSingleThreadExecutor().submit(() -> {
            AuthData authData = null;
            try {
                runOnUiThread(() -> textView.setText("Parsing pepper_cred.xml from assets/robot!"));
                String userIp = editTextRobotIp.getText().toString().trim();
                authData = parseXML(withRobot, userIp);
                AuthData finalAuthData = authData;
                runOnUiThread(() -> textView.append("\n Connecting to robot at IP " + finalAuthData.getIp()));
                if (!userIp.isEmpty()) saveIpToHistory(userIp);
                runOnUiThread(() -> textView.append("\n Successfully parsed credentials, trying to open port via SSH!"));
            } catch (Exception e) {
                runOnUiThread(() -> textView.setText("Error: " + e.getMessage()));
                return;
            }

            buttonRestart = findViewById(R.id.buttonRestart);
            AuthData finalAuthData1 = authData;
            buttonRestart.setOnClickListener(v -> {
                String currentIp = editTextRobotIp.getText().toString().trim();
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                String lastUsedIp = prefs.getString(KEY_LAST_USED_IP, null);
                String fallbackIp = finalAuthData1.getIp(); // always available

                if (!currentIp.isEmpty()) {
                    if (saveIpToHistory(currentIp)) {
                        Toast.makeText(this, "Valid IP saved to history.", Toast.LENGTH_SHORT).show();
                        buttonClearHistory.setEnabled(true);
                        //if (buttonClearHistory != null) {}
                    } else if (Patterns.IP_ADDRESS.matcher(currentIp).matches()) {
                        //Toast.makeText(this, "IP is already the last used. Not saved.", Toast.LENGTH_SHORT).show();
                    } else {
                        // Invalid IP: revert to last used or fallback
                        String resetIp = lastUsedIp != null ? lastUsedIp : fallbackIp;
                        editTextRobotIp.setText(resetIp);
                        editTextRobotIp.setSelection(resetIp.length());
                        Toast.makeText(this, "Invalid IP. Reverted to previous IP.", Toast.LENGTH_SHORT).show();
                    }
                }

                startMainActivity(true, debugModeCheckbox.isChecked()); // Always proceed
            });

            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String lastUsedIp = prefs.getString(KEY_LAST_USED_IP, null);

            // Only autofill if the user hasn't typed anything AND no saved IP exists
            if (parsedIp != null && !parsedIp.trim().isEmpty() && lastUsedIp == null) {
                runOnUiThread(() -> {
                    String currentText = editTextRobotIp.getText().toString().trim();
                    if (currentText.isEmpty()) {
                        editTextRobotIp.setText(parsedIp);
                        //editTextRobotIp.setSelection(parsedIp.length()); // Move cursor to end
                    }
                });
            }


            try {
                if (withRobot) {
                    openPort(authData);
                }
                QiSDK.setAuthData(authData);
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                intent.putExtra("withRobot", withRobot);
                intent.putExtra("debugMode", debugMode);
                startActivity(intent);
                finish();
            } catch (IOException e) {
                runOnUiThread(() -> textView.append("\nError opening port: " + e.getMessage()));
            }
        });
    }

    private AuthData parseXML(boolean withRobot, String overrideIp) throws XmlPullParserException, IOException {
        String username = null, password = null, ip = null, sshIdentifier = null;
        int qiPort = 0, sshPort = 0;

        InputStream inputStream = this.getAssets().open(withRobot ? "robot/pepper_cred.xml" : "robot/pepper_cred_dummy.xml");

        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XmlPullParser xpp = factory.newPullParser();
        xpp.setInput(new InputStreamReader(inputStream));

        int eventType = xpp.getEventType();
        String tag, text = "";
        while (eventType != XmlPullParser.END_DOCUMENT) {
            tag = xpp.getName();
            if (eventType == xpp.TEXT) {
                text = xpp.getText();
            } else if (eventType == xpp.END_TAG) {
                switch (tag) {
                    case "IP":
                        ip = text;
                        break;
                    case "QiPort":
                        qiPort = Integer.parseInt(text);
                        break;
                    case "User":
                        username = text;
                        break;
                    case "Password":
                        password = text;
                        break;
                    case "SSHIdentifier":
                        sshIdentifier = text;
                        break;
                    case "SSHPort":
                        sshPort = Integer.parseInt(text);
                        break;
                }
            }
            eventType = xpp.next();
        }

        parsedIp = ip;
        if (overrideIp != null && !overrideIp.isEmpty()) {
            ip = overrideIp;
        }

        if (ip == null || username == null || password == null || qiPort == 0 || sshPort == 0 || sshIdentifier == null) {
            throw new XmlPullParserException("Missing information in XML; please refer to example");
        }

        return new AuthData(ip, qiPort, username, password, sshIdentifier, sshPort);
    }

    private void openPort(AuthData authData) throws IOException {
        SSHConnection sshConnection = new SSHConnection(authData);
        sshConnection.executeCommand("nohup /opt/aldebaran/www/apps/core/bin/qi-secure-gateway --qi-url tcp://127.0.0.1:9559 --qi-listen-url tcps://0.0.0.0:9876 &");
    }
}
