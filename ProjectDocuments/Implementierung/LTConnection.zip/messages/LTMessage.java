package edu.kit.anthropomatik.h2t.pepper.basicapp.messages;

import androidx.annotation.NonNull;

import com.aldebaran.qi.sdk.object.locale.Language;
import com.aldebaran.qi.sdk.object.locale.Locale;
import com.aldebaran.qi.sdk.object.locale.Region;

import org.json.JSONException;
import org.json.JSONObject;

public class LTMessage {

    private final JSONObject message;

    /**
     * Create a new LT message object from a JSONObject coming from the LT.
     * @param message The LT message as a JSONObject.
     */
    public LTMessage(JSONObject message) {
        this.message = message;
    }

    /**
     * Determines for a message if was sent by the bot.
     * @return True if from bot.
     */
    public boolean isFromBot() {
        String sender;
        try {
            sender = this.message.getString("sender");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return sender.contains("bot");
    }

    /**
     * Get text content from a message.
     * @return The text it contains.
     */
    @NonNull
    @Override
    public String toString() {
        try {
            return this.message.getString("seq");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Turn the message into a conversation item (starting with the speaker before the text).
     * @return The message content and the speaker in front of it as a String.
     * */
    protected String toConvItem() {
        String seq = this.toString();
        String name;
        if (this.isFromBot()) {
            name = "Robot: ";
        } else {
            name = "User: ";
        }
        return name + seq;
    }

    /**
     * Return the language of the message as a Locale object.
     * The supported languages are a collection of languages officially and non-officially supported
     * by Llama 3.1 we may use for our case.
     * @return The language of the message as a Locale object.
     */
    public Locale getLocale() {
        String lid = this.getLanguageId();
        switch(lid) {
            case "de":
                return new Locale(Language.GERMAN, Region.GERMANY);
            case "fr":
                return new Locale(Language.FRENCH, Region.FRANCE);
            case "it":
                return new Locale(Language.ITALIAN, Region.ITALY);
            case "ru":
                return new Locale(Language.RUSSIAN, Region.RUSSIAN_FEDERATION);
            case "es":
                return new Locale(Language.SPANISH, Region.SPAIN);
            case "tr":
                return new Locale(Language.TURKISH, Region.TURKEY);
            case "zh":
                return new Locale(Language.CHINESE, Region.CHINA);
            case "hi":
                return new Locale(Language.HINDI, Region.INDIA);
            case "pt":
                return new Locale(Language.PORTUGUESE, Region.PORTUGAL);
            default:
                return new Locale(Language.ENGLISH, Region.UNITED_STATES);
        }
    }

    private String getLanguageId() {
        try {
            return this.message.getString("lid");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}
