package edu.kit.anthropomatik.h2t.pepper.basicapp.messages;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.util.Deque;
import java.util.LinkedList;

public class LTMessageList {
    private final LinkedList<LTMessage> msgList;
    private final int maxSize;
    private boolean hasNewMsg;

    /**
     * Create a new message list and set the maximum number of messages.
     * @param maxSize Maximum number of messages inside the message list.
     */
    public LTMessageList(int maxSize) {
        this.maxSize = maxSize;
        this.msgList = new LinkedList<>();
        this.hasNewMsg = false;
    }

    /**
     * Add a new message (coming from the LT) and remove the oldest.
     * @param message The new message to add.
     */
    public void add(JSONObject message) {
        if (this.msgList.size() >= this.maxSize) {
            this.msgList.removeFirst();
        }
        this.msgList.addLast(new LTMessage(message));
        this.hasNewMsg = true;
    }

    /**
     * Converts the full message list into a String.
     * @return String representation of the full message list..
     */
    @NonNull
    public String toString() {
        String result = "";
        for (LTMessage message: this.msgList) {
            result += message.toConvItem() + "\n";
        }
        return result;
    }

    /**
     * Check if the message list has a new not yet requested message.
     * @return If there is an new not yet requested message.
     */
    public boolean hasNewMsg() {
        return this.hasNewMsg;
    }

    /**
     * Return the newest message from the bot.
     * Reset the newest message variable.
     * @return The newest message, null if non exist / error.
     */
    public LTMessage getNewestBotMsg() {
        for (int i = (this.msgList.size() - 1); i >= 0; i--) {
            LTMessage msg = this.msgList.get(i);
            if (msg.isFromBot()) {
                this.hasNewMsg = false;
                return msg;
            }
        }
        return null;
    }
}
