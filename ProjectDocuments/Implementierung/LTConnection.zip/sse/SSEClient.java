package edu.kit.anthropomatik.h2t.pepper.basicapp.sse;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.launchdarkly.eventsource.EventHandler;
import com.launchdarkly.eventsource.EventSource;
import com.launchdarkly.eventsource.MessageEvent;

import java.net.URI;
import java.time.Duration;

import okhttp3.Headers;

public class SSEClient {

    private final SSEHandler sseHandler;
    private EventSource eventSourceSse;
    private final String url;
    private final boolean localhost;


    /**
     * Creates a new SSEClient.
     * @param url Url to connect to.
     * @param sseHandler Handler for SSE (caller).
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public SSEClient(String url, SSEHandler sseHandler, boolean localhost) {
        this.url = url;
        this.sseHandler = sseHandler;
        this.localhost = localhost;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void initSse() {
        try {
            this.eventSourceSse = this.buildEventSource();
            if (this.eventSourceSse != null) {
                this.eventSourceSse.start();
            }
        } catch (Exception e) {
            Log.i("SSE_CONNECTION", "Token possibly invalid!");
            throw new RuntimeException(e);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private EventSource buildEventSource() {
        EventHandler eventHandler = new DefaultEventHandler(this.sseHandler);
        EventSource.Builder builder = new EventSource.Builder(eventHandler, URI.create(this.url))
                .connectTimeout(Duration.ofSeconds(3))
                .backoffResetThreshold(Duration.ofSeconds(3));
        if (this.localhost) {
            builder.headers(Headers.of("Host", "localhost"));
        }
        return builder.build();
    }

    private static class DefaultEventHandler implements EventHandler {

        private final SSEHandler sseHandler;

        public DefaultEventHandler(SSEHandler sseHandler) {
            this.sseHandler = sseHandler;
        }

        @Override
        public void onOpen() {
            sseHandler.onSSEConnectionOpened();
        }

        @Override
        public void onClosed() {
            sseHandler.onSSEConnectionClosed();
        }

        @Override
        public void onMessage(String event, MessageEvent messageEvent) {
            sseHandler.onSSEEventReceived(event, messageEvent);
        }

        @Override
        public void onError(Throwable t) {
            sseHandler.onSSEError(t);
        }

        @Override
        public void onComment(String comment) {
            Log.i("SSE_CONNECTION", comment);
        }
    }

    public void disconnect() {
        new Thread(() -> {
            try {
                if (this.eventSourceSse != null) {
                    this.eventSourceSse.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}

