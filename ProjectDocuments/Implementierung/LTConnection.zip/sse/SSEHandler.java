package edu.kit.anthropomatik.h2t.pepper.basicapp.sse;

import com.launchdarkly.eventsource.MessageEvent;

public interface SSEHandler {
    public void onSSEConnectionOpened();

    public void onSSEConnectionClosed();

    public void onSSEEventReceived(String event, MessageEvent messageEvent);

    public void onSSEError(Throwable t);
}
